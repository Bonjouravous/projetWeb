<?php

namespace Gregwar\RST\LaTeX;

use Gregwar\RST\Environment as Base;

class Environment extends Base
{
}
