<?php

namespace Gregwar\RST\LaTeX\Nodes;

use Gregwar\RST\Nodes\Node as Base;

class LaTeXMainNode extends Base
{
    public function render()
    {
        return '';
    }
}
