<?php

namespace Gregwar\RST\LaTeX\Nodes;

use Gregwar\RST\Nodes\MetaNode as Base;

class MetaNode extends Base
{
    public function render()
    {
        return '';
    }
}
