<?php

namespace Gregwar\RST\Nodes;

abstract class ParagraphNode extends Node
{
}
