<?php

namespace Gregwar\RST\Nodes;

abstract class AnchorNode extends Node
{
}
