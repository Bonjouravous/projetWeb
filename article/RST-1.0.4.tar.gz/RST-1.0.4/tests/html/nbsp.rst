
This is a non breakable space: a~b
