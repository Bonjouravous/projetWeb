
.. |test| note::
    This is an important thing

|test|

|test|

