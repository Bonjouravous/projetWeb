
.. code-block:: java

    protected void f()
    {
    }
