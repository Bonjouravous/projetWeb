Inclusion test
==============

Test this paragraph is present.

.. include:: inclusion-newline-include.rst
