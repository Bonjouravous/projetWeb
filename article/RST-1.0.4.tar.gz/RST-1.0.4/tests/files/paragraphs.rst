Paragraph 1

Paragraph 2
With two lines

Paragraph 3
With *emphasis*

