Introduction page
=================

This is an introduction page!

Reference to the :doc:`index`

Reference to the :doc:`Index <index>`

Reference to the :doc:`Index, paragraph toc <index#toc>`

