
.. url:: magic-link

Another page
============

Hello!

.. redirection-title:: subdirective

See also
--------

See also: :doc:`subdirective`
