
.. .. test::

Index file
==========

Testing `xkcd`_ !

This is the index of all!

.. toctree:: 
    :depth: 3

    otherpage
    subdir/testing_sub
    special

Testing reference in a list:

* :doc:`subdir/testing_sub`

Including
---------

.. include:: include.rst

.. _`xkcd`: http://xkcd.com/

