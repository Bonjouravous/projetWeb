
You can include a file with the include pseudo-directive::

    .. include:: file.rst
